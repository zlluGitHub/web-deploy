<template>
  <div class="ide-index">
    <Split v-model="split">
      <div slot="left" class="left">
        <div class="ide-hedaer">
          <i class="fa fa-codepen"></i>
          <span>项目名称</span>
        </div>
        <div class="operation-warp">
          <div>文件（12）</div>
          <div><i class="fa fa-search"></i> <i class="fa fa-plus"></i></div>
        </div>
        <Tree :data="treeData" expand-node></Tree>
      </div>
      <div slot="right" class="right">
        <div class="ide-hedaer">
          <i class="fa fa-undo"></i>
          <i class="fa fa-repeat"></i>
          <i class="fa fa-outdent"></i>
          <i class="fa fa-font"></i>
        </div>
        <ul class="file-scroll-bar">
          <li>
            <i class="fa fa-file-code-o"></i> <span>index.html</span> <i class="fa fa-remove"></i>
          </li>
          <li class="active">
            <i class="fa fa-file-code-o"></i> <span>index.html</span><i class="fa fa-remove"></i>
          </li>
          <li>
            <i class="fa fa-file-code-o"></i> <span>index.html</span><i class="fa fa-remove"></i>
          </li>
        </ul>
        <div class="content">
          <AceEditor
            v-model="content"
            @init="editorInit"
            :lang="language"
            :theme="theme"
            width="100%"
            height="800px"
            :options="{
              enableBasicAutocompletion: true,
              enableLiveAutocompletion: true,
              fontSize: 14,
              highlightActiveLine: true,
              enableSnippets: true,
              showLineNumbers: true,
              tabSize: 2,
              showPrintMargin: false,
              showGutter: true,
            }"
            :commands="[
              {
                name: 'save',
                bindKey: { win: 'Ctrl-s', mac: 'Command-s' },
                exec: dataSumit,
                readOnly: true,
              },
            ]"
          />
        </div>
      </div>
    </Split>
  </div>
</template>

<script>
import Decorate from "@/components/Decorate";
import AceEditor from "vuejs-ace-editor";
export default {
  components: {
    Decorate,
    AceEditor,
  },
  // props: {
  //   msg: String
  // },

  data() {
    return {
      split: 0.15,
      content:"",
      theme: "", //monokai、mono_industrial
      language: "javascript", //json、java、javascript、html、scala、sql
      treeData: [
        {
          title: "my-project",
          expand: true,
          children: [
            {
              title: "html",
              expand: true,
              children: [
                {
                  title: "index.html",
                },
                {
                  title: "index.html",
                },
              ],
            },
            {
              title: "src",
              expand: true,
              children: [
                {
                  title: "index.html",
                },
                {
                  title: "index.html",
                },
              ],
            },
          ],
        },
      ],
    };
  },
  watch: {},
  created() {
      // this.$request
      //   .get("/swd/fileEdit/content", { params: { bid: this.$route.query.bid } })
      //   .then((res) => {
      //     if (res.data.code === 200) {
      //       this.content = res.data.data
      //     }
      //   });
      this.$request
        .get("/swd/fileEdit/catalog", { params: { bid: this.$route.query.bid } })
        .then((res) => {
          if (res.data.code === 200) {
            this.content = res.data.data
          }
        });
  },
  mounted() {},
  methods: {
    editorInit: function () {
      require("brace/ext/language_tools"); //language extension prerequsite...
      require("brace/mode/html");
      require("brace/mode/javascript"); //language
      require("brace/mode/scala");
      require("brace/mode/sql");
      // require("brace/mode/less");
      // require("brace/theme/monokai");
      // require("brace/theme/mono_industrial");
      // require("brace/snippets/javascript"); //snippet
    },
  },
};
</script>
<style lang="scss" scoped>
.ide-index {
  background: #fff;
  height: 100%;
  .ide-hedaer {
    background: #efefef;
    height: 35px;
    display: flex;
    align-items: center;
    padding: 0 15px;
    i {
      margin-right: 10px;
    }
  }
  .left {
    .ide-hedaer {
      font-size: 17px;
    }
    .operation-warp {
      display: flex;
      justify-content: space-between;
      height: 35px;
      padding: 0 15px;
      align-items: center;
      border-bottom: 1px solid #eee;
      i {
        margin-left: 5px;
        cursor: pointer;
      }
    }
    /deep/ .ivu-tree {
      padding: 0 20px;
    }
  }
  .right {
    .ide-hedaer {
      i {
        margin: 0 10px;
        cursor: pointer;
      }
    }
    .file-scroll-bar {
      display: flex;
      height: 35px;
      padding: 0 20px;
      background: #f8f8f8;
      li {
        display: flex;
        align-items: center;
        padding: 0 15px;
      span{
          cursor: pointer;
      }
        i {
          margin-right: 5px;
        }
        .fa-remove{
          margin-left: 10px;
            cursor: pointer;
        }
        &.active {
          background: #fff;
        }
      }
    }
    .content {
      // padding-top: 20px;
      background: #fff;
    }
  }
  /deep/ .ivu-split-trigger-bar-con.vertical {
    display: none;
  }
  /deep/ .ivu-split-trigger-vertical {
    background: transparent;
    border-right: 0;
  }
}
</style>
