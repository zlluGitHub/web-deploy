<template>
  <section>login</section>
</template>

<script>
export default {
  name: "sections",
  props: {
    msg: String,
  },
};
</script>
<style lang="scss" scoped>
section {
  background: #fff;
}
</style>
