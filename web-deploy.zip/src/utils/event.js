/**
 * 事件池(事件管理器)
 * 通过事件监听传值
 */
 import mitt from 'mitt';
 export const events = mitt();